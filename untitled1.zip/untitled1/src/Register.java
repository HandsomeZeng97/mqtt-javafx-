import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.HPos;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import java.awt.*;
import java.io.*;

public class Register extends Application{
    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        TextField username = new TextField();
        TextField password = new TextField();
        TextField accounts = new TextField();
        pane.add(new Label("Register new accounts"), 1, 0);
        pane.add(new Label("Accounts:"), 0, 1);
        pane.add(accounts, 1, 1);
        pane.add(new Label("Password:"), 0, 2);
        pane.add(password, 1, 2);
        pane.add(new Label("Username:"), 0, 3);
        pane.add(username, 1, 3);
        Button register = new Button("Achieve");
        GridPane.setHalignment(register, HPos.RIGHT);
        pane.add(register, 1, 4);
        register.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                File file = new File("D:\\IdeaProjects\\untitled1\\account.txt");
                try {
                    FileWriter output = new FileWriter(file, true);
                    output.append(accounts.getText()+"\r\n");
                    output.append(password.getText()+"\r\n");
                    output.append(username.getText()+"\r\n");
                    output.close();
                    primaryStage.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                return;
            }
        });

        Scene scene = new Scene(pane, 250, 150);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Register");
        primaryStage.show();
    }

}