import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.HPos;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.input.*;

import java.awt.event.ActionListener;
import java.io.*;
import java.util.ArrayList;
import java.util.*;


public class ChatRoom extends Application implements ActionListener {
    public String Topic;
    public String Username;
    private ObservableList<String> logList = FXCollections.observableArrayList();
    private Receiver recv;
    TextField content = new TextField();

    public ChatRoom(String Username){
        this.Username = Username;
    }
    @Override
    public void start(Stage primaryStage) throws IOException {
        ObservableList<String> topicList = FXCollections.observableArrayList();
        File file1 = new File("D:\\IdeaProjects\\untitled1\\topic.txt");
        BufferedReader br = new BufferedReader(new FileReader(file1));
        while(topicList.add(br.readLine())){
            if(topicList.get(topicList.size()-1) == null){
                topicList.remove(topicList.size()-1);
                break;
            }
        }
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        ChoiceBox topic = new ChoiceBox ();
        topic.setItems(topicList);
        ListView<String> log = new ListView<String>(logList);
        topic.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                Topic = topicList.get(newValue.intValue());
//                System.out.println(Topic);
            }
        });

        recv = new Receiver(logList);
        recv.start();
        content.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.ENTER){
//                logList.add(Username+" say: "+content.getText());
                recv.SendMessage(Username+" say: "+content.getText());
                Calendar cal = Calendar.getInstance();
                String time = String.format("%04d-%02d-%02d", cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)+1, cal.get(Calendar.DATE));
                File file = new File("D:\\IdeaProjects\\untitled1\\Log\\"+time+"-"+Topic+".log");
                try {
                    FileWriter output = new FileWriter(file, true);
                    output.append(this.Username+" say: "+content.getText()+"\r\n");
                    output.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

//                log.setText(log.getText()+content.getText()+"\r\n");
                content.clear();
            }
        });
        Label name = new Label("Username: "+Username);
        name.setFont(new Font("Arial", 15));
        pane.add(name, 1, 0, 2, 1);
        pane.add(new Label("Topic:"), 0, 1);
        pane.add(topic, 1, 1, 2, 1);
//        pane.add(new Button("Add"), 2, 0);
        pane.add(new Label("Log:"), 0, 2);
        pane.add(log, 1, 2, 3, 1);
        Button sign = new Button("Browse history");
        Button send = new Button("send");
        Button add = new Button("Add topic");
        add.setAlignment(Pos.CENTER_RIGHT);
        GridPane.setHalignment(add, HPos.RIGHT);
        send.setAlignment(Pos.CENTER_RIGHT);
        GridPane.setHalignment(send, HPos.RIGHT);
        TextField addTopic = new TextField();
        pane.add(addTopic, 2, 1);
        pane.add(add,3,1);
        pane.add(send,3,3);
        pane.add(sign,1, 3);
        pane.add(new Label("Content:"), 0, 4);
        pane.add(content, 1, 4, 3, 1);
        add.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                File file = new File("D:\\\\IdeaProjects\\\\untitled1\\\\topic.txt");
                try {
                    FileWriter output = new FileWriter(file, true);
                    output.append(addTopic.getText()+"\n");
                    output.close();
                    topicList.add(addTopic.getText());
                    addTopic.clear();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        sign.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Search search = new Search();
                search.start(new Stage());
            }
        });
        send.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                recv.SendMessage(Username+" say: "+content.getText());
//                logList.add(Username+" say: "+content.getText());
                Calendar cal = Calendar.getInstance();
                File file = new File("D:\\IdeaProjects\\untitled1\\Log\\"+cal.get(Calendar.YEAR)+"-"+(int)(cal.get(Calendar.MONTH)+1)+"-"+cal.get(Calendar.DATE)+"-"+Topic+".log");
                try {
                    FileWriter output = new FileWriter(file, true);
                    output.append(Username+" say: "+content.getText()+"\r\n");
                    output.close();
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

//                log.setText(log.getText()+content.getText()+"\r\n");
                content.clear();
            }
        });
        Scene scene = new Scene(pane, 500, 600);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("聊天室");
        primaryStage.show();
    }

    @Override
    public void actionPerformed(java.awt.event.ActionEvent e) {
        if(content.getText().length() != 0){
            recv.SendMessage(Username+" say: "+content.getText());
        }
    }
}
