import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.HPos;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Prompt extends Application{
//    private String aaa = "11111";
//
//    public Prompt(String tick){
//        this.aaa = tick;
//    }

    private String string;
    public Prompt(String a){
        this.string = a;
    }
    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        pane.add(new Label(this.string), 0, 0);

        Scene scene = new Scene(pane, 200, 100);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Inform");
        primaryStage.setResizable(false);
        primaryStage.show();
    }
}