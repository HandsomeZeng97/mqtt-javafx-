import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.HPos;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.*;
import javafx.scene.input.*;

import java.io.*;
import java.util.ArrayList;

public class Search extends Application{
    private ObservableList<String> item = FXCollections.observableArrayList();
    public int che = -1;
    @Override
    public void start(Stage primaryStage) {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        ChoiceBox choose = new ChoiceBox(FXCollections.observableArrayList("Topic", "Date", "Key word"));
        TextField Choose = new TextField();
        ListView<String> log = new ListView<String>(item);
        pane.add(choose, 0 , 0);
        pane.add(Choose, 1 , 0);
        pane.add(log, 0, 1, 2, 1);
        //选择搜索类型
        choose.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {

            @Override
            public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
                che = newValue.intValue();
            }
        });
        // 0代表Toipc的操作，其他一样
        Choose.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.ENTER) {
                if (che == 0) {
                    item.clear();
                    File undo = new File("D:\\IdeaProjects\\untitled1\\Log\\");
                    String[] names = undo.list();
                    for (String s : names) {
                        boolean ok = s.contains(Choose.getText() + ".log");
                        if (ok) {
                            String mm = "";
                            for (int i = 0; i < 10; i++) {
                                mm += s.charAt(i);
                            }
                            if(item.size() == 0 || item.get(item.size()-1).equals(mm) == false)
                                item.add(mm);
                        }
                    }
                    Choose.clear();
                }
                else if(che == 1){
                    item.clear();
                    File undo = new File("D:\\IdeaProjects\\untitled1\\Log\\");
                    String[] names = undo.list();
                    for(String s:names){
                        boolean ok = s.contains(Choose.getText()+"-");
                        if(ok){
                            String mm = "";
                            for(int i = Choose.getText().length()+1; s.charAt(i) != '.'; i++){
                                mm += s.charAt(i);
                            }
                            item.add(mm);
                        }
                    }
                    Choose.clear();
                }
                else if(che == 2){
                    item.clear();
                    File undo = new File("D:\\IdeaProjects\\untitled1\\Log\\");
                    String[] names = undo.list();
                    for(String s:names){
                        String id = "D:\\IdeaProjects\\untitled1\\Log\\"+s;
                        File file = new File(id);
                        try {
                            BufferedReader br = new BufferedReader(new FileReader(file));
                            ArrayList<String> word = new ArrayList<String>();
                            boolean ok = false;
                            while(word.add(br.readLine())){
                                if(word.get(word.size()-1) == null){
                                    word.remove(word.size()-1);
                                    break;
                                }
                                if(word.get(word.size()-1).contains(Choose.getText())){
                                    ok = true;
                                }
                            }
                            if(ok){
                                item.add(s);
                            }
                        } catch (FileNotFoundException e1) {
                            e1.printStackTrace();
                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                    }
                    Choose.clear();
                }
            }
        });
        Scene scene = new Scene(pane, 350, 450);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Search");
        primaryStage.show();
    }
}