import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.geometry.HPos;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;

public class Logger extends Application{
    public static void main(String[] args){
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setPadding(new Insets(10,10,10,10));
        pane.setHgap(5.5);
        pane.setVgap(5.5);
        TextField username = new TextField();
        PasswordField password = new PasswordField();
        Button register = new Button("Register");
        pane.add(new Label("Username:"), 0, 0);
        pane.add(username, 1, 0);
        pane.add(new Label("Password:"), 0, 1);
        pane.add(password, 1, 1);
        pane.add(register, 0, 2);
        Button sign = new Button("Login");
        sign.setAlignment(Pos.CENTER_RIGHT);
        GridPane.setHalignment(sign, HPos.RIGHT);
        pane.add(sign,1, 2);

        register.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Register register1 = new Register();
                register1.start(new Stage());
            }
        });
        sign.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                File file = new File("D:\\IdeaProjects\\untitled1\\account.txt");
                try {
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    ArrayList<String> user = new ArrayList<String>();
                    while(user.add(br.readLine())){
                        if(user.get(user.size()-1) == null){
                            break;
                        }
                    }
                    user.remove(user.size()-1);
                    int ok = -1;
                    for(int i = 0; i < user.size(); i += 3){
                        if(user.get(i).equals(username.getText()) && user.get(i+1).equals(password.getText())){
                            ok = i;
                            break;
                        }
                    }
                    if(ok == -1){
                        Prompt prompt = new Prompt("Account or Password Error!");
                        prompt.start(new Stage());
                    }
                    else{
                        ChatRoom chatRoom = new ChatRoom(user.get(ok+2));
                        chatRoom.start(new Stage());
                        primaryStage.close();

                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        password.setOnKeyPressed(event -> {
            if(event.getCode() == KeyCode.ENTER){
                File file = new File("D:\\IdeaProjects\\untitled1\\account.txt");
                try {
                    BufferedReader br = new BufferedReader(new FileReader(file));
                    ArrayList<String> user = new ArrayList<String>();
                    while(user.add(br.readLine())){
                        if(user.get(user.size()-1) == null){
                            break;
                        }
                    }
                    user.remove(user.size()-1);
                    int ok = -1;
                    for(int i = 0; i < user.size(); i += 3){
                        if(user.get(i).equals(username.getText()) && user.get(i+1).equals(password.getText())){
                            ok = i;
                            break;
                        }
                    }
                    if(ok == -1){
                        Prompt prompt = new Prompt("Account or Password Error!");
                        prompt.start(new Stage());
                    }
                    else{
                        ChatRoom chatRoom = new ChatRoom(user.get(ok+2));
                        chatRoom.start(new Stage());
                        primaryStage.close();

                    }

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        Scene scene = new Scene(pane, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.setTitle("Login");
        primaryStage.show();
    }
}